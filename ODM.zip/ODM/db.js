//28.01.25

const mongoose = require("mongoose")
const cust = require("./schema")

async function db() {
    try{   
        await mongoose.connect("mongodb://localhost:27017/customer")      //connection created              //localhost:27017 - default   | customer - db name
        console.log("Database is connected");

    }catch(e){
        console.log("error");
    }

/*
    ====================================  traditional method   ============================
        const newCustomer = new cust({
            name:'sanj',
            age:19,
            address:{
                pincode:4567,
                state:"TN"
            },
            hobbies:['drawing','gamming']
        })
        newCustomer.save()

    //modern method
        const newCustomer = cust.create({
            name:'sri',
            age : 200,
            address:{
                pincode:4577,
                state:"TN"
            },
            hobbies:['drawing','gamming']
        })
*/
    // const newCustomer = await new cust({
    //     name:'Kavi',
    //     age: 20,
    //     email : "kavi@gmail.com",
    //     friend : "67985e50aff76bfc3962f291",
    //     address:{
    //         pincode:4567,
    //         state:"TN"
    //     },
    //     hobbies:['drawing','gamming']
    // })
    // console.log(newCustomer);
    


//const customerData = await cust.findById("67985f6eaaf76993addce438", {name : 1, age : 1, _id : 0}) ------> IN MONGO DB

// ------> IN MONGOOSE PACKAGE
const customerData = await cust.find().where("name").equals("sri").limit(1)
console.log(customerData);

// const update = await cust.updateOne({name :"sri"}, {$set : {age : 22}})
// console.log(update);

}    
db()